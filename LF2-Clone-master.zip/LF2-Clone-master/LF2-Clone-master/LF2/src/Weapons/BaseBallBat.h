#pragma once
#include "Weapon.h"

class BaseBallBat : public Weapon {
public:
	BaseBallBat();
};
