#pragma once
#include "Weapon.h"
class IceSword : public Weapon {
public:
	IceSword();
};