#pragma once
#include "Weapon.h"
class HookWeapon : public Weapon {
public:
	HookWeapon();
 };