// stdafx.h

#define WIN32_LEAN_AND_MEAN